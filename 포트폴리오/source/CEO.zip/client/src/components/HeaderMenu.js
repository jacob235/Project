import React, { Component } from 'react';

import Menu from 'components/Menu';

class HeaderMenu extends Component {
  render(){
      return(
          <div>
          <Menu/>
          </div>
      );
  }
}


export default HeaderMenu;