import React from 'react';

class Header extends React.Component{
    render(){
        return(
            <div> 
                    <header id="header" class="alt">
					<h1 id="logo">연극어때</h1>
				    </header>

            </div>
        )
    }
}
export default Header;