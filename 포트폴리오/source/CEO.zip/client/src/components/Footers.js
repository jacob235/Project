import React from 'react';

class Footers extends React.Component{
    render(){
        return(
            <div> 
            <footer id="footer">
			비트캠프 서울시 서초구 강남대로 459 (서초동, 백암빌딩)<br/>
			사업자등록번호 : 214-85-24928 <br/>
			(주)비트컴퓨터 서초본원 대표이사 : 조현정 <br/>
			문의 : 02-3486-9600 <br/>
			팩스 : 02-6007-1245 <br/>
			통신판매업 신고번호 : 제 서초-00098호<br/>
			개인정보보호관리책임자 : 최종진
		    </footer>
                
            </div>
        )
    }
}
export default Footers;