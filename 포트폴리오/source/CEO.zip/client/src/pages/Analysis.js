import React from 'react';
import HeaderMenu from '../components/HeaderMenu';

const Analysis = ({match}) => {
    return (
        <div>
        <HeaderMenu/>
        </div>
    );
};

export default Analysis;