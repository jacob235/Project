import React from 'react';

const Registoration = ({match}) => {
    return (
        <div>
           
        </div>
    );
};

export default Registoration;